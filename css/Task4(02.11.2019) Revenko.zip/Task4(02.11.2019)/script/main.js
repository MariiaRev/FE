/*function switch_btn()
{
	let sw_off = document.getElementById('sw-off');
	let sw_on = document.getElementById('sw-on');
	if (sw_off.style.display == "block")
	{
		sw_off.style.display = "none";
		sw_off.animate({
        width: "70%",
        opacity: 0.4,
      }, 1500 );
		sw_on.style.display = "block";
	}
	else
	{
		sw_off.style.display = "block";
		sw_on.style.display = "none";
	}
	
}*/